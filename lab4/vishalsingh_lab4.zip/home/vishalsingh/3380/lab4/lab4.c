#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_COMMAND_LENGTH 100
#define MAX_PARAMETER_LENGTH 50

// Function to display the help info
void help() {
    printf(" -------------------------------------HELP-----------------------------------------\n");

    printf(" Valid verbs are:\n");
    printf(" help:                  Displays this text\n");
    printf(" systeminfo:            Displays the System information.\n");
    printf(" diskuse:               Shows the amount of disk being used in the current directory.\n");
    printf(" drives:                Lists all of the ext4 mounted partitions as well as their size and free space.\n");
    printf(" processinfo:           Displays information about All the running processes.\n");
    printf(" findprocess [process]: Displays information about the specified process. If not present, searches for 'root'.\n");
    printf(" jobtree [username]:    Shows the processes running related to a specific username.\n");
    printf(" exit:                  Exits this shell and returns to your original shell.\n");
    printf(" NOTE: Elements in square brackets are optional and verbs are Case-Sensitive\n");
}
// Function to execute a command with or without parameters creating processes
void executeCommand(char *command, char *parameter) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) { // A Child process
        if (strcmp(command, "help") == 0) {
            help();
        } else {
            char *args[4];
            args[0] = strdup("/bin/bash");
            args[1] = strdup("-c");
            args[2] = strdup(command);

            if (parameter != NULL) {
                args[3] = strdup(parameter);
                args[4] = NULL;
            } else {
                args[3] = NULL;
            }

            execv(args[0], args);
            perror("Execv failed");
            exit(EXIT_FAILURE);
        }
    } else { // the Parent process
        wait(NULL);//This wait(NULL) call in the parent process ensures that it waits for the child process to finish before continuing
    }
}
// Function to display disk usage information
void diskuse() {
    executeCommand("du -sch", NULL);
}
// Function to display the system information
void systeminfo() {
    executeCommand("uname -a", NULL);
}
// Function to display info about the  mounted drives
void drives() {
    executeCommand("df -h -t ext4", NULL);
}

//Function to display process tree related to a specific username
void jobtree(const char *username) {
    char command[MAX_COMMAND_LENGTH];
    if (username == NULL) {
        snprintf(command, sizeof(command), "ps -o user:32,pid,stime,tty,cmd -U vishalsingh --forest");
    } else {
        snprintf(command, sizeof(command), "ps -o \"user:32,pid,stime,tty,cmd\" -U %s --forest", username);
    }
    system(command);
}

// Function to display information about all the running processes
void processinfo() {
    executeCommand("ps aux", NULL);
}

// Function to display information about a specified process or 'root' if not specified
void findprocess(const char *process) {
    if (process == NULL) {
        printf("Note: No Process provided so using the root as default process\n");
        process = "root";
    }

    char command[MAX_COMMAND_LENGTH];
    snprintf(command, sizeof(command), "ps aux | grep %s", process);
    executeCommand(command, NULL);
}
// Main Function 
int main() {
    char input[MAX_COMMAND_LENGTH];

    printf("Welcome to VI- shell by Vishal! Type 'help' for a list of valid commands.\n");

    while (1) {
	printf("Verb >> ");

        if (fgets(input, sizeof(input), stdin) == NULL) {
            break; // Exit if there's an error reading input
        }
        input[strcspn(input, "\n")] = '\0'; // Remove trailing newline

        // Tokenize input
        char *verb = strtok(input, " ");
        char *username = strtok(NULL, " ");

        // Execute corresponding verb
        if (strcmp(verb, "exit") == 0) {
	    system("ps -ef | grep -e $USER > /dev/null 2>&1");
            printf("Exiting VI-Shell. Bye, Be back Soon....!\n");
            break;
        } else if (strcmp(verb, "help") == 0) {
            help();
        } else if (strcmp(verb, "diskuse") == 0) {
            diskuse();
        } else if (strcmp(verb, "systeminfo") == 0) {
 	   systeminfo();
        } else if (strcmp(verb, "drives") == 0) {
            drives();
        } else if (strcmp(verb, "jobtree") == 0) {
            jobtree(username);
	}else if (strcmp(verb, "processinfo")==0){
	    processinfo();
        } else if (strcmp(verb, "findprocess") == 0) {
            findprocess(username);
        } else {
            printf("Invalid verb. Type 'help' for a list of valid verbs.\n");
        }

    }

    return 0;

}

