#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>
#include <unistd.h>

int SignalCounter = 0; //Counter to count the number of SIGINT signals received
int maximum_value = 5; // Maximum number of SIGINT signals allowed

// Function declarations
void sig_int_handler(int signum);
void sig_quit_handler(int signum);
void sig_usr1_handler(int signum);

// Signal handler for SIGINT (CTRL-C)
void sig_int_handler(int signum) {
    if (SignalCounter < maximum_value) {  //Checking if Maximum Value is not exceeded
        printf(" This is the %d time you pressed ctrl-c\n", ++SignalCounter); //Incrementing and prinitng the Counter
        printf("Wait for another signal ...\n");
    } 
        
    else {
      // Maximum value exceeded so deactivating SIGINT handler
        printf("MAXIMUM value exceeded. Deactivating SIGINT handler.\n");
        signal(SIGINT, SIG_DFL);  // Deactivates the signal handler
    }
}

// Signal handler for SIGUSR1
void sig_usr1_handler(int signum) {
    printf("Child sent a signal so I guess you are bored, have a great day!\n");
    printf("You Pressed ^c %d times.\n", SignalCounter);
    printf("Program is Over, and Exiting Now.\n"); 

    exit(EXIT_SUCCESS);

}


// Signal handler for SIGQUIT (CTRL-\)
void sig_quit_handler(int signum) {
    pid_t pid = fork();  //Creating the Child Process
    if (pid > 0) {
	return;
    } else if (pid == 0) {  // Child process
        printf("I am the child and I am sending a signal\n");
        kill(getppid(), SIGUSR1);  // Sending SIGUSR1 signal to parent
        if (kill(getppid(), SIGUSR1) == -1) {//Another Error Check
            perror("Error: Kill failed");
        }
        exit(EXIT_SUCCESS);
    } else {  
        perror("fork");
        exit(EXIT_FAILURE);

    }

}
//Main Function
int main() {
    
        // signal handlers
        signal(SIGINT, sig_int_handler);
        signal(SIGQUIT, sig_quit_handler);
        signal(SIGUSR1, sig_usr1_handler);

        printf("Wait for another signal ...\n");
        // check for any errors  
        if (signal(SIGINT, sig_int_handler) == SIG_ERR || signal(SIGQUIT, sig_quit_handler) == SIG_ERR) {
        perror("signal");
        return EXIT_FAILURE;
    }
    int running = 1;
    while (running) { //creates a forever loop

        pause();  // Waiting for a signal

    }

    return 0;
}

