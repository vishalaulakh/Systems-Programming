#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO_CLIENT_SERVER "/tmp/client-server_fifo" // Defining the FIFO path for client-server communication
#define FIFO_SERVER_CLIENT "/tmp/server-client_fifo" // Defining the FIFO path for server-client communication
#define BUFFER_SIZE 1024 // Setting a buffer size based on lab document

struct packet {
    int nbytes;
    char payload[BUFFER_SIZE];
};

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename> {Please Provide A File Directory}\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    printf("Clients program started\n");

    // Checking if the FIFOs exist
    if (access(FIFO_CLIENT_SERVER, F_OK) == -1 || access(FIFO_SERVER_CLIENT, F_OK) == -1) {
        fprintf(stderr, "Communication FIFOs not found\n");
        exit(EXIT_FAILURE);
    }

    printf("Communication FIFOs found\n");

    // Open FIFOs
    int client_to_server_fd = open(FIFO_CLIENT_SERVER, O_WRONLY);
    int server_to_client_fd = open(FIFO_SERVER_CLIENT, O_RDONLY);
    if (client_to_server_fd == -1 || server_to_client_fd == -1) {
        perror("Error opening the FIFOs");
        exit(EXIT_FAILURE);
    }

    printf("FIFOs opened successfully\n");

    // Sending the filename to the server
    char *filename = argv[1];
    write(client_to_server_fd, filename, strlen(filename) + 1);
    printf("Filename sent to the server: %s\n", filename);

    // Opening the  file to read and send to server
    int file_fd = open(filename, O_RDONLY);
    if (file_fd == -1) {
        perror("Error opening file");
        close(client_to_server_fd);
        close(server_to_client_fd);
        exit(EXIT_FAILURE);
    }

    printf("File opened successfully\n");

    struct packet pkt;
    int total_bytes_sent = 0;
    int nbytes;
    while ((nbytes = read(file_fd, pkt.payload, BUFFER_SIZE)) > 0) {
        pkt.nbytes = nbytes;
        total_bytes_sent += nbytes;
        write(client_to_server_fd, &pkt, sizeof(pkt));
        printf("Sent %d bytes to server\n", nbytes);
    }

    // Sending end of the file message
    pkt.nbytes = 0;
    write(client_to_server_fd, &pkt, sizeof(pkt));
    printf("End of file sent\n");

    // Receiving server acknowledgment
    read(server_to_client_fd, &pkt, sizeof(pkt));
    printf("Server response: %s\n", pkt.payload);

    // Closing file descriptors
    close(file_fd);
    close(client_to_server_fd);
    close(server_to_client_fd);

    printf("Client program finished\n");

    return 0;
}

